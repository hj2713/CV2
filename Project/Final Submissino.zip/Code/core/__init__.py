# Make core a module
